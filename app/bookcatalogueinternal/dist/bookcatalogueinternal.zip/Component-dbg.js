sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("internal.bookcatalogueinternal.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);